// initially created by Jeremy Shaeffer
// updated by Joe Avey

#include "move.h"

#include <unistd.h>
#include <stdlib.h>
#include <assert.h>

#include "dungeon.h"
#include "heap.h"
#include "move.h"

#include "character.h"
#include "npc.h"
#include "utils.h"
#include "path.h"
#include "pc.h"

void do_combat(dungeon_t *d, void *atk, void *def)
{
  set_alive(def, 0);
  if (def != d->pc) {
    d->num_monsters--;
  }
}

void move_character(dungeon_t *d, void *c, pair_t next)
{
  if (charpair(next) &&
      ((next[dim_y] != get_position(c, dim_y)) ||
       (next[dim_x] != get_position(c, dim_x)))) {
    do_combat(d, c, charpair(next));
  } else {
    /* No character in new position. */

    d->character[get_position(c, dim_y)][get_position(c, dim_x)] = NULL;
    set_position(c, next[dim_x], next[dim_y]);
    d->character[get_position(c, dim_y)][get_position(c, dim_x)] = c;
  }
}

void do_moves(dungeon_t *d, int user_command)
{
  pair_t next;
  void *c;

  /* Remove the PC when it is PC turn.  Replace on next call.  This allows *
   * use to completely uninit the heap when generating a new level without *
   * worrying about deleting the PC.                                       */

  if (pc_is_alive(d)) {
    heap_insert(&d->next_turn, d->pc);
  }

  while (pc_is_alive(d) && ((c = heap_remove_min(&d->next_turn)) != d->pc)) {
    if (!get_alive(c)) {
      if (d->character[get_position(c, dim_y)][get_position(c, dim_x)] == c) {
        d->character[get_position(c, dim_y)][get_position(c, dim_x)] = NULL;
      }
      if (c != d->pc) {
        npc_delete(c);
      }
      continue;
    }

    set_next_turn(c, get_next_turn(c) + (1000 / get_speed(c)));

    npc_next_pos(d, c, next);
    move_character(d, c, next);

    heap_insert(&d->next_turn, c);
  }

  if (pc_is_alive(d) && c == d->pc) {
    pc_next_pos(d, next, user_command);
    next[dim_x] += get_position(c, dim_x);
    next[dim_y] += get_position(c, dim_y);
    if (mappair(next) <= ter_floor) {
      mappair(next) = ter_floor_hall;
    }
    move_character(d, c, next);

    update_light_terrain_c(d, d->pc);

    dijkstra(d);
    dijkstra_tunnel(d);

    set_next_turn(c, get_next_turn(c) + (1000 / get_speed(c)));
  }
}

void dir_nearest_wall(dungeon_t *d, void *c, pair_t dir)
{
  dir[dim_x] = dir[dim_y] = 0;

  if (get_position(c, dim_x) != 1 && get_position(c, dim_x) != DUNGEON_X - 2) {
    dir[dim_x] = (get_position(c, dim_x) > DUNGEON_X - get_position(c, dim_x) ? 1 : -1);
  }
  if (get_position(c, dim_y) != 1 && get_position(c, dim_y) != DUNGEON_Y - 2) {
    dir[dim_y] = (get_position(c, dim_y) > DUNGEON_Y - get_position(c, dim_y) ? 1 : -1);
  }
}

uint32_t in_corner(dungeon_t *d, void *c)
{
  uint32_t num_immutable;

  num_immutable = 0;

  num_immutable += (mapxy(get_position(c, dim_x) - 1,
	  	  	  	  get_position(c, dim_y)    ) == ter_wall_immutable);
  num_immutable += (mapxy(get_position(c, dim_x) + 1,
	  	  	  	  get_position(c, dim_y)    ) == ter_wall_immutable);
  num_immutable += (mapxy(get_position(c, dim_x)    ,
	  	  	  	  get_position(c, dim_y) - 1) == ter_wall_immutable);
  num_immutable += (mapxy(get_position(c, dim_x)    ,
	  	  	  	  get_position(c, dim_y) + 1) == ter_wall_immutable);

  return num_immutable > 1;
}

uint32_t move_pc(dungeon_t *d, uint32_t dir)
{
  return 1;
}
