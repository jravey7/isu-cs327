/*
 * user_input.c
 *
 *  Created on: Mar 6, 2016
 *      Author: Joe
 */

#include "user_input.h"



void show_monster_list(dungeon_t * d)
{
	// get list of monsters
	monsters_list_t * monsters = get_monsters_list(d);

	int next_command;

	do
	{
		if((next_command == KEY_DOWN) && monsters->next)
			monsters = monsters->next;
		if((next_command == KEY_UP) && monsters->prev)
					monsters = monsters->prev;

		pair_t pc_pos = {get_position(d->pc, dim_x),get_position(d->pc, dim_y)};

		display_monsters_list(monsters, pc_pos);

		next_command = determine_cmd();
	}while(next_command != ESC_KEY);

}

int determine_cmd()
{

	int key = 0;

	if(getch() == '\033')
	{
		nodelay(stdscr, TRUE);
		getch();
		switch(getch())
		{
		case 'A':
			key = KEY_UP;
			break;
		case 'B':
			key = KEY_DOWN;
			break;
		case 'C':
			key = KEY_RIGHT;
			break;
		case 'D':
			key = KEY_LEFT;
			break;
		}
		if(key == 0)
			key = ESC_KEY;

		nodelay(stdscr, FALSE);
	}
	return key;
}

void display_monsters_list(monsters_list_t * mon, pair_t pc_pos)
{
	int mon_count = 0, i;

	mvprintw(2, 30, " ------Monster list------ ");

	// clear space for the list
	for(i = 3; i < 21; i++)
	{
		mvprintw(i, 30, "                          ");
	}

	// print the monsters in the list (up to 19 total)
	while(mon && mon_count < 19)
	{
		char mon_info[24] = {};
		char horz_str[10] = {};
		char vert_str[10] = {};

		int horz_offset = mon->position[dim_x] - pc_pos[dim_x];
		int vert_offset = mon->position[dim_y] - pc_pos[dim_y];

		if(vert_offset < 0)
			sprintf(vert_str, "%2d north", vert_offset * -1);
		else if(vert_offset > 0)
			sprintf(vert_str, "%2d south", vert_offset);

		if(horz_offset < 0)
			sprintf(horz_str, "%2d east", horz_offset * -1);
		else if(horz_offset > 0)
			sprintf(horz_str, "%2d west", horz_offset);

		if((horz_str[0]) && (vert_str[0]))
			sprintf(mon_info, "%c, %s and %s", mon->symbol, vert_str, horz_str);
		else if(horz_str[0])
			sprintf(mon_info, "%c, %s", mon->symbol, horz_str);
		else if(vert_str[0])
			sprintf(mon_info, "%c, %s", mon->symbol, vert_str);

		mvprintw(mon_count + 3, 31, mon_info);

		mon = mon->next;
		mon_count++;
	}
}

monsters_list_t * get_monsters_list(dungeon_t * d)
{
	// iterate through the character map grabbing the symbol
	// and distance to pc of each monster encountered
	int i, j;


	monsters_list_t * monsters = calloc(1, sizeof(monsters_list_t));
	for(i = 0; i < DUNGEON_Y; i++)
		for(j = 0; j < DUNGEON_X; j++)
		{
			void * cur = d->character[i][j];

			if(!cur || (cur == &d->pc))
				continue;

			if(!monsters->head) // this is the first monster in the list
			{
				monsters->prev = NULL;
				monsters->symbol = get_symbol(cur);
				monsters->position[dim_x] = get_position(cur, dim_x);
				monsters->position[dim_y] = get_position(cur, dim_y);
				monsters->head = monsters;
			}
			else
			{
				monsters->next = malloc(sizeof(monsters_list_t));
				monsters->next->prev = monsters;
				monsters->next->symbol = get_symbol(cur);
				monsters->next->position[dim_x] = get_position(cur, dim_x);
				monsters->next->position[dim_y] = get_position(cur, dim_y);
				monsters->next->head = monsters->head;
				monsters = monsters->next;
			}

		}

	//reset the list to the head
	monsters = monsters->head;

	return monsters;
}

int valid_user_command(int user_command)
{
	int ret = 0;

	switch(user_command)
	{
	case 'y':
	case '7':
	case '8':
	case 'k':
	case '9':
	case 'u':
	case '6':
	case 'l':
	case '3':
	case 'n':
	case '2':
	case 'j':
	case '1':
	case 'b':
	case '4':
	case 'h':
	case '>':
	case '<':
	case ' ':
	case 'm':
	case 'S':
		ret = 1;
		break;
	default:
		ret = 0;
	}

	return ret;
}
