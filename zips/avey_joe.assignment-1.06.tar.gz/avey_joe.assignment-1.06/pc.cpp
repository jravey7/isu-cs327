/*
 * pc_cpp.cpp
 *
 *  Created on: Mar 14, 2016
 *      Author: Joe
 */

#include <stdlib.h>

#include "string.h"

#include "dungeon.h"
#include "utils.h"
#include "move.h"
#include "path.h"
#include "pc.h"

void pc_delete(void * v)
{
	if(v)
	{
		PC * pc = (PC *) v;
		delete pc;
	}
}

uint32_t pc_is_alive(dungeon_t *d)
{
  return ((PC *) d->pc)->alive;
}

void place_pc(dungeon_t *d)
{
	((PC *) d->pc)->position[dim_y] = rand_range(d->rooms->position[dim_y],
                                     (d->rooms->position[dim_y] +
                                      d->rooms->size[dim_y] - 1));
  ((PC *) d->pc)->position[dim_x] = rand_range(d->rooms->position[dim_x],
                                     (d->rooms->position[dim_x] +
                                      d->rooms->size[dim_x] - 1));
}

void config_pc(dungeon_t *d)
{
//  memset(&d->pc, 0, sizeof (d->pc));
//  ((PC *) d->pc)->symbol = '@';

	PC * pc;
	pair_t pc_pos = {1,1};
	pc = new PC(pc_pos, PC_SPEED);

	d->pc = (void *) pc;

  place_pc(d);

  d->character[((PC *) d->pc)->position[dim_y]][((PC *) d->pc)->position[dim_x]] = d->pc;

  dijkstra(d);
  dijkstra_tunnel(d);
}

uint32_t pc_next_pos(dungeon_t *d, pair_t dir, int user_command)
{
  dir[dim_y] = dir[dim_x] = 0;

  pair_t attempt = {};

  switch(user_command)
  {
	case 'y': //upper left
	case '7':
		attempt[dim_y] = -1;
		attempt[dim_x] = -1;
		break;
	case '8': // up
	case 'k':
		attempt[dim_y] = -1;
		attempt[dim_x] = 0;
		break;
	case '9': // upper right
	case 'u':
		attempt[dim_y] = -1;
		attempt[dim_x] = 1;
		break;
	case '6': // right
	case 'l':
		attempt[dim_y] = 0;
		attempt[dim_x] = 1;
		break;
	case '3': // lower right
	case 'n':
		attempt[dim_y] = 1;
		attempt[dim_x] = 1;
		break;
	case '2': //down
	case 'j':
		attempt[dim_y] = 1;
		attempt[dim_x] = 0;
		break;
	case '1': //lower left
	case 'b':
		attempt[dim_y] = 1;
		attempt[dim_x] = -1;
		break;
	case '4': //left
	case 'h':
		attempt[dim_y] = 0;
		attempt[dim_x] = -1;
  }

  pair_t imm_check = {(int8_t)(attempt[dim_x] + ((PC *) d->pc)->position[dim_x]),
		  (int8_t)(attempt[dim_y] + ((PC *) d->pc)->position[dim_y])};

  if(mappair(imm_check) != ter_wall_immutable)
  {
	  dir[dim_x] = attempt[dim_x];
	  dir[dim_y] = attempt[dim_y];
  }

  return 0;
}

void update_light_terrain_c(dungeon_t * d, void * pc)
{
	if(pc == d->pc && pc)
	{
		((PC *) pc)->update_light_terrain(d);
	}
}

void PC::update_light_terrain(dungeon_t * d)
{
	int i, j;
	for(i = this->position[dim_y] - PC_LIGHT_RADIUS; i < (this->position[dim_y]
			+ PC_LIGHT_RADIUS); i++)
		for(j = this->position[dim_x] - PC_LIGHT_RADIUS; j < (this->position[dim_x]
			+ PC_LIGHT_RADIUS); j++)
		{
			if(i < 0 || i > DUNGEON_Y - 1 || j < 0 || j > DUNGEON_X - 1)
				continue;
			this->light_terrain[i][j] = d->map[i][j];
		}
}

uint8_t get_pc_light_terrain(pair_t p, void * pc)
{
	if(pc)
	{
		return ((PC *)pc)->light_terrain[p[dim_y]][p[dim_x]];
	}
	return -1;
}

