/*
 * user_input.h
 *
 *  Created on: Mar 6, 2016
 *      Author: Joe
 */

#ifndef SRC_USER_INPUT_H_
#define SRC_USER_INPUT_H_

#ifdef __cplusplus
extern "C" {
#endif

#include <ncurses.h>

#include "dungeon.h"
#include "dims.h"
#include "character.h"

#define ESC_KEY 27

typedef struct monster_list {
	struct monster_list * next; // null at the end
	struct monster_list * prev; // null at the head
	struct monster_list * head;
	char symbol;
	pair_t position;
}monsters_list_t;

void show_monster_list(dungeon_t * d);
monsters_list_t * get_monsters_list(dungeon_t * d);
void display_monsters_list(monsters_list_t * mon, pair_t pc_pos);
int determine_cmd();
int valid_user_command(int user_command);

#ifdef __cplusplus
}
#endif

#endif /* SRC_USER_INPUT_H_ */
