/*

 * character_cpp.cpp
 *
 *  Created on: Mar 14, 2016
 *      Author: Joe
 */

#include "character.h"

#include "heap.h"
#include "dungeon.h"


int Character::character_sequence_number = 0;

void set_alive(void * v, int alive)
{
	if(v)
	{
		((Character *) v)->alive = alive;
	}
}

int get_alive(void * v)
{
	if(v)
	{
		return ((Character *)v)->alive;
	}
	return -1;
}

void set_next_turn(void *v, int next_turn)
{
	if(v)
	{
		((Character *) v)->next_turn = next_turn;
	}
}

int get_next_turn(void *v)
{
	if(v)
	{
		return ((Character *)v)->next_turn;
	}
	return -1;
}

uint8_t get_position(void * v, int dim)
{
	if(v && (dim == dim_x || dim == dim_y))
	{
		return ((Character *) v)->position[dim];
	}
	return 0;
}

void set_position(void * v, int x_pos, int y_pos)
{
	if(v)
	{
		((Character *) v)->position[dim_x] = x_pos;
		((Character *) v)->position[dim_y] = y_pos;
	}
}

void set_speed(void * v, int speed)
{
	if(v)
	{
		((Character *)v)->speed = speed;
	}
}

int get_speed(void * v)
{
	if(v)
	{
		return ((Character *)v)->speed;
	}
	return -1;
}

char get_symbol(void * v)
{
	if(v)
	{
		return ((Character *)v)->symbol;
	}
	return 'x';
}

char * print_character(void * v)
{
	if(v)
	{
		Character *c = (Character *) v;
		static char string[80];

		snprintf(string, 80, "%d:%d", c->next_turn, c->sequence_number);

		return string;
	}
	return NULL;
}

void character_delete(void *c)
{
  if (c) {
	  Character * del = (Character *) c;
      delete del;
  }
}

int32_t compare_characters_by_next_turn(const void *character1,
        const void *character2)
{
  int32_t diff;

  Character * one = (Character *) character1;
  Character * two = (Character *) character2;

  diff = (one->next_turn - two->next_turn);
  return diff ? diff : (one->sequence_number - two->sequence_number);
}

uint32_t can_see(dungeon_t *d, void *voyeur, void *exhibitionist)
{
  /* Application of Bresenham's Line Drawing Algorithm.  If we can draw *
   * a line from v to e without intersecting any walls, then v can see  *
   * e.  Unfortunately, Bresenham isn't symmetric, so line-of-sight     *
   * based on this approach is not reciprocal (Helmholtz Reciprocity).  *
   * This is a very real problem in roguelike games, and one we're      *
   * going to ignore for now.  Algorithms that are symmetrical are far  *
   * more expensive.                                                    */

  pair_t first, second;
  pair_t del, f;
  int16_t a, b, c, i;

  Character * voy = (Character *) voyeur;
  Character * exh = (Character *) exhibitionist;

  first[dim_x] = voy->position[dim_x];
  first[dim_y] = voy->position[dim_y];
  second[dim_x] = exh->position[dim_x];
  second[dim_y] = exh->position[dim_y];

  if ((abs(first[dim_x] - second[dim_x]) > VISUAL_RANGE) ||
      (abs(first[dim_y] - second[dim_y]) > VISUAL_RANGE)) {
    return 0;
  }

  /*
  mappair(first) = ter_debug;
  mappair(second) = ter_debug;
  */

  if (second[dim_x] > first[dim_x]) {
    del[dim_x] = second[dim_x] - first[dim_x];
    f[dim_x] = 1;
  } else {
    del[dim_x] = first[dim_x] - second[dim_x];
    f[dim_x] = -1;
  }

  if (second[dim_y] > first[dim_y]) {
    del[dim_y] = second[dim_y] - first[dim_y];
    f[dim_y] = 1;
  } else {
    del[dim_y] = first[dim_y] - second[dim_y];
    f[dim_y] = -1;
  }

  if (del[dim_x] > del[dim_y]) {
    a = del[dim_y] + del[dim_y];
    c = a - del[dim_x];
    b = c - del[dim_x];
    for (i = 0; i <= del[dim_x]; i++) {
      if ((mappair(first) < ter_floor) && i && (i != del[dim_x])) {
        return 0;
      }
      /*      mappair(first) = ter_debug;*/
      first[dim_x] += f[dim_x];
      if (c < 0) {
        c += a;
      } else {
        c += b;
        first[dim_y] += f[dim_y];
      }
    }
    return 1;
  } else {
    a = del[dim_x] + del[dim_x];
    c = a - del[dim_y];
    b = c - del[dim_y];
    for (i = 0; i <= del[dim_y]; i++) {
      if ((mappair(first) < ter_floor) && i && (i != del[dim_y])) {
        return 0;
      }
      /*      mappair(first) = ter_debug;*/
      first[dim_y] += f[dim_y];
      if (c < 0) {
        c += a;
      } else {
        c += b;
        first[dim_x] += f[dim_x];
      }
    }
    return 1;
  }

  return 1;
}
