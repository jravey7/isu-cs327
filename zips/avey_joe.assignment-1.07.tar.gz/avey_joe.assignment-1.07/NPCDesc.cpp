/*
 * npc_desc.cpp
 *
 *  Created on: Mar 22, 2016
 *      Author: Joe
 */

#include "NPCDesc.h"
#include <unistd.h>
#include <cstring>

using namespace std;

int seek_line_str(ifstream *desc_stream, const char * line_str)
{
	char line[1000] = {};

	if(!desc_stream->getline(line, 1000))
		return 0;

	while(strcmp(line, line_str) != 0)
	{
		if(!desc_stream->getline(line, 1000))
			return 0;
	}

	return 1;
}

int get_linetype(char * type)
{
	if(type == NULL)
		return 0;

	if(strcmp(type, "NAME") == 0)
	{
		return DESC_NAME;
	}
	if(strcmp(type, "DESC") == 0)
	{
		return DESC_DESC;
	}
	if(strcmp(type, "COLOR") == 0)
	{
		return DESC_COLOR;
	}
	if(strcmp(type, "SPEED") == 0)
	{
		return DESC_SPEED;
	}
	if(strcmp(type, "ABIL") == 0)
	{
		return DESC_ABIL;
	}
	if(strcmp(type, "HP") == 0)
	{
		return DESC_HP;
	}
	if(strcmp(type, "DAM") == 0)
	{
		return DESC_DAM;
	}
	if(strcmp(type, "SYMB") == 0)
	{
		return DESC_SYMB;
	}
	return 0;
}

uint8_t str_to_color(char * color)
{
	if(strcmp(color, "RED") == 0)
	{
		return RED;
	}
	if(strcmp(color, "GREEN") == 0)
	{
		return GREEN;
	}
	if(strcmp(color, "BLUE") == 0)
	{
		return BLUE;
	}
	if(strcmp(color, "CYAN") == 0)
	{
		return CYAN;
	}
	if(strcmp(color, "YELLOW") == 0)
	{
		return YELLOW;
	}
	if(strcmp(color, "MAGENTA") == 0)
	{
		return MAGENTA;
	}
	if(strcmp(color, "WHITE") == 0)
	{
		return WHITE;
	}
	if(strcmp(color, "BLACK") == 0)
	{
		return BLACK;
	}

	return BAD_COLOR;
}

const char * get_color_str(int color)
{
	switch(color)
	{
	case RED:
		return "RED";
	case GREEN:
		return "GREEN";
	case BLUE:
		return "BLUE";
	case CYAN:
		return "CYAN";
	case YELLOW:
		return "YELLOW";
	case MAGENTA:
		return "MAGENTA";
	case WHITE:
		return "WHITE";
	case BLACK:
		return "BLACK";
	}

	return "BAD_COLOR";
}

int verify_dice_str(char * dice_str)
{
	int d = 0;
	int plus = 0;
	while(*dice_str)
	{
		if(*dice_str == 'd')
			d = 1;
		if(*dice_str == '+')
			plus = 1;
		dice_str++;
	}
	if(d && plus)
		return 1;

	return 0;
}

//returns:
// a vector of monster descriptions
vector<NPCDesc> read_monster_desc()
{
	char * home = getenv("HOME");
	char filename[1000] = {};
	sprintf(filename, "%s/.rlg327/monster_desc.txt", home);

	vector<NPCDesc> desc_list;

	ifstream desc_stream;
	desc_stream.open(filename, ifstream::in);

	char testFileType[1000] = {};
	desc_stream.getline(testFileType, 1000);
	if(strcmp(testFileType, "RLG327 MONSTER DESCRIPTION 1"))
		return desc_list;

	while(desc_stream.peek())
	{
		seek_line_str(&desc_stream, "BEGIN MONSTER");

		char * name = (char *) calloc(50, 1);
		char * desc = (char *) calloc(2000, 1);
		uint8_t color = 0;
		char * speed = (char *) calloc(50, 1);
		char * abil = (char *) calloc(100, 1);
		char * hp = (char *) calloc(50, 1);
		char * dam = (char *) calloc(50, 1);
		char symb;

		char line[1000] = {};
		if(!desc_stream.getline(line, 1000))
			break;

		int8_t success = 0;
		int8_t loop_count = 0;
		int8_t bad_param = 0;
		while(strcmp(line, "END") && !bad_param)
		{
			char linecopy[1000];
			strcpy(linecopy, line);
			char * type = strtok(linecopy, " ");

			int linetype = get_linetype(type);

			switch(linetype)
			{
			case DESC_NAME:
			{
				strncpy(name, strtok(NULL, "\n"), 50);
				success |= DESC_NAME;
				break;
			}
			case DESC_DESC:
			{
				int length = 0;
				int count_between_nl = 0;
				char next_char = desc_stream.get();
				while(next_char)
				{
					if(next_char != '\n')
					{
						desc[length++] = next_char;
						count_between_nl++;
					}
					else if(desc_stream.peek() == '.')
					{
						break;
					}
					else
					{
						desc[length++] = '\n';
						count_between_nl = 0;
					}

					if(count_between_nl >= 78)
					{
						desc[length++] = '\n';
						count_between_nl = 0;
					}

					next_char = desc_stream.get();
				}
				strcat(desc, "\n");
				if(next_char != '.')
					seek_line_str(&desc_stream, ".");
				success |= DESC_DESC;
				break;
			}
			case DESC_COLOR:
			{
				color = str_to_color(strtok(NULL, " "));
				if(color == BAD_COLOR)
					bad_param = 1;
				success |= DESC_COLOR;
				break;
			}
			case DESC_SPEED:
			{
				strncpy(speed, strtok(NULL, " "), 50);
				if(!verify_dice_str(speed))
					bad_param = 1;
				success |= DESC_SPEED;
				break;
			}
			case DESC_ABIL:
			{
				strncpy(abil, strtok(NULL, "\n"), 100);
				success |= DESC_ABIL;
				break;
			}
			case DESC_HP:
			{
				strncpy(hp, strtok(NULL, " "), 50);
				if(!verify_dice_str(hp))
					bad_param = 1;
				success |= DESC_HP;
				break;
			}
			case DESC_DAM:
			{
				strncpy(dam, strtok(NULL, " "), 100);
				if(!verify_dice_str(dam))
					bad_param = 1;
				success |= DESC_DAM;
				break;
			}
			case DESC_SYMB:
			{
				symb = *(strtok(NULL, "\n"));
				success |= DESC_SYMB;
				break;
			}
			}

			// if i have all of the traits defined
			if((success & 0xff) == (0xff))
				break;

			if(++loop_count == 8)
				break;

			desc_stream.getline(line, 1000);
		}
		if(bad_param)
			continue;

		// if i have all of the traits defined
		if((success & 0xff) == (0xff))
			desc_list.push_back(NPCDesc(name, desc, color, speed, abil, hp, dam, symb));

	}

	return desc_list;
}

void NPCDesc::print()
{
	cout << this->NAME << endl;
	cout << this->DESC;
	cout << this->SYMB << endl;
	cout << get_color_str(this->COLOR) << endl;
	cout << this->SPEED << endl;
	cout << this->ABIL << endl;
	cout << this->HP << endl;
	cout << this->DAM << endl;

}

