/*
 * pc_cpp.h
 *
 *  Created on: Mar 14, 2016
 *      Author: Joe
 */

#ifndef PC_H_
#define PC_H_


#include "character.h"
#include "dungeon.h"

#ifdef __cplusplus
// needs to inherit everything from Character
// like speed, next_turn, etc. (see Character class)
class PC: public Character {
public:
	terrain_type_t light_terrain[DUNGEON_Y][DUNGEON_X];

	void update_light_terrain(dungeon_t * d);

	PC(pair_t position, int32_t speed){
		this->speed = speed;
		symbol = '@';
		this->position[0] = position[0];
		this->position[1] = position[1];
		next_turn = 0;
		alive = 1;
		sequence_number = Character::get_seq_num();;
		memset(&light_terrain, ter_wall, DUNGEON_Y * DUNGEON_X * sizeof(terrain_type_t));
	}
};
#endif

#ifdef __cplusplus
extern "C" {
#endif

uint32_t pc_is_alive(dungeon_t *d); // add to dungeon.c
void config_pc(dungeon_t *d);
uint32_t pc_next_pos(dungeon_t *d, pair_t dir, int user_command);
void place_pc(dungeon_t *d);
void pc_delete(void * v);
uint8_t get_pc_light_terrain(pair_t p, void * pc);
void update_light_terrain_c(dungeon_t * d, void * pc);

#ifdef __cplusplus
}
#endif


#endif /* PC_H_ */
