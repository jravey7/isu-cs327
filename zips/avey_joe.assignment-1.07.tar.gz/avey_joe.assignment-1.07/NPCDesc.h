/*
 * npc_desc.h
 *
 *  Created on: Mar 22, 2016
 *      Author: Joe
 */

#ifndef NPC_DESC_H_
#define NPC_DESC_H_

#include <iostream>
#include <fstream>
#include <ncurses.h>
#include <stdint.h>
#include <vector>
#include <cstring>

#include "npc.h"

#define DESC_NAME 0x01
#define DESC_DESC 0x02
#define DESC_COLOR 0x04
#define DESC_SPEED 0x08
#define DESC_ABIL 0x10
#define DESC_HP 0x20
#define DESC_DAM 0x40
#define DESC_SYMB 0x80

enum {
	BAD_COLOR,
	RED,
	GREEN,
	BLUE,
	CYAN,
	YELLOW,
	MAGENTA,
	WHITE,
	BLACK
};

class NPCDesc {
private:
	char * NAME;
	char * DESC;
	uint8_t COLOR;
	char * SPEED;
	char * ABIL;
	char * HP;
	char * DAM;
	char SYMB;
public:
	NPCDesc(char * name, char * desc, uint8_t color, char * speed,
			char * abil, char * hp, char * dam, char symb){
		NAME = name;
		DESC = desc;
		COLOR = color;
		SPEED = speed;
		ABIL = abil;
		HP = hp;
		DAM = dam;
		SYMB = symb;
	}
	void print();
};

std::vector<NPCDesc> read_monster_desc();

#endif /* SRC_NPC_DESC_H_ */
