/*
 * character_cpp.h
 *
 *  Created on: Mar 12, 2016
 *      Author: Joe
 */

#ifndef CHARACTER_H_
#define CHARACTER_H_

# include <stdint.h>
# include "dims.h"

typedef struct dungeon dungeon_t;
typedef struct npc npc_t;
typedef struct pc pc_t;
typedef struct dice_t dice_t;

#ifdef __cplusplus

class Character {
public:
	static int character_sequence_number;
	char symbol;
	pair_t position;
	int32_t speed;
	uint32_t next_turn;
	uint32_t alive;
	/* The priority queue is not stable.  It's nice to have a record of *
	* how many monsters have been created, and this sequence number    *
	* serves that purpose, but more importantly, prioritizing lower    *
	* sequence numbers ahead of higher ones guarantees that turn order *
	* is fair.  PC gets sequence number zero, and a global sequence,   *
	* stored in the dungeon, is incremented each time a NPC is         *
	* created and copied here then.                                    */
	uint32_t sequence_number;
	Character(){
		this->symbol = 0;
		this->speed = 0;
		this->position[0] = 0;
		this->position[1] = 0;
		this->next_turn = 0;
		this->sequence_number = 1000000;
		this->alive = 0;
	}
	Character(char symbol, pair_t position, int32_t speed)
		: symbol(symbol), speed(speed) {
		this->position[0] = position[0];
		this->position[1] = position[1];
		this->next_turn = 0;
		this->sequence_number = character_sequence_number++;
		this->alive = 1;
	}
	static int get_seq_num()
	{
		return Character::character_sequence_number++;
	}
};

#endif

#ifdef __cplusplus
extern "C" {
#endif

char *print_character(const void *v);
int32_t compare_characters_by_next_turn(const void *character1,
                                        const void *character2);
uint32_t can_see(dungeon_t *d, void *voyeur, void *exhibitionist);
void character_delete(void *c);
char get_symbol(void * v);
void set_alive(void * v, int alive);
int get_alive(void *v);
int8_t get_position(void * v, int dim);
void set_position(void * v, int x_pos, int y_pos);
void set_speed(void * v, int speed);
int get_speed(void * v);
void set_next_turn(void *v, int next_turn);
int get_next_turn(void *v);

#ifdef __cplusplus
}
#endif

#endif /* CHARACTER_H_ */
