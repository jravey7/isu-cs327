// initially created by Jeremy Shaeffer
// updated by Joe Avey

#include <stdlib.h>

#include "string.h"

#include "dungeon.h"
#include "pc.h"
#include "utils.h"
#include "move.h"
#include "path.h"

void pc_delete(pc_t *pc)
{
  if (pc) {
    free(pc);
  }
}

uint32_t pc_is_alive(dungeon_t *d)
{
  return d->pc.alive;
}

void place_pc(dungeon_t *d)
{
  d->pc.position[dim_y] = rand_range(d->rooms->position[dim_y],
                                     (d->rooms->position[dim_y] +
                                      d->rooms->size[dim_y] - 1));
  d->pc.position[dim_x] = rand_range(d->rooms->position[dim_x],
                                     (d->rooms->position[dim_x] +
                                      d->rooms->size[dim_x] - 1));
}

void config_pc(dungeon_t *d)
{
  memset(&d->pc, 0, sizeof (d->pc));
  d->pc.symbol = '@';

  place_pc(d);

  d->pc.speed = PC_SPEED;
  d->pc.next_turn = 0;
  d->pc.alive = 1;
  d->pc.sequence_number = 0;
  d->pc.pc = calloc(1, sizeof (*d->pc.pc));
  d->pc.npc = NULL;

  d->character[d->pc.position[dim_y]][d->pc.position[dim_x]] = &d->pc;

  dijkstra(d);
  dijkstra_tunnel(d);
}

uint32_t pc_next_pos(dungeon_t *d, pair_t dir, int user_command)
{
  dir[dim_y] = dir[dim_x] = 0;

  pair_t attempt = {};

  switch(user_command)
  {
	case 'y': //upper left
	case '7':
		attempt[dim_y] = -1;
		attempt[dim_x] = -1;
		break;
	case '8': // up
	case 'k':
		attempt[dim_y] = -1;
		attempt[dim_x] = 0;
		break;
	case '9': // upper right
	case 'u':
		attempt[dim_y] = -1;
		attempt[dim_x] = 1;
		break;
	case '6': // right
	case 'l':
		attempt[dim_y] = 0;
		attempt[dim_x] = 1;
		break;
	case '3': // lower right
	case 'n':
		attempt[dim_y] = 1;
		attempt[dim_x] = 1;
		break;
	case '2': //down
	case 'j':
		attempt[dim_y] = 1;
		attempt[dim_x] = 0;
		break;
	case '1': //lower left
	case 'b':
		attempt[dim_y] = 1;
		attempt[dim_x] = -1;
		break;
	case '4': //left
	case 'h':
		attempt[dim_y] = 0;
		attempt[dim_x] = -1;
  }

  pair_t imm_check = {attempt[dim_x] + d->pc.position[dim_x], attempt[dim_y] + d->pc.position[dim_y]};

  if(mappair(imm_check) != ter_wall_immutable)
  {
	  dir[dim_x] = attempt[dim_x];
	  dir[dim_y] = attempt[dim_y];
  }

  return 0;
}
